package com.binarysearch;

public class Node {
    //instance variable of Node class
    public int data;
    public Node left;
    public Node right;

    //constructor
    public Node(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }

}